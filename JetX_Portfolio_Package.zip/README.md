# JetX Application Portfolio — Divyanshu Samal

Built for: **Engine Performance & Testing Engineer (GET), JR20260802 — JetX Propulsions Pvt. Ltd.**

This repo contains two self-directed engineering projects plus a fixture
concept sketch, built in one week specifically to close the technical gap
between my (Mechanical Engineering, non-aerospace-specific) background and
this role's stated requirements. Everything here is disclosed as exactly
that — a foundation, not finished production work.

## Contents

```
code/
  turbojet_cycle_model.py       # Real-cycle Brayton/turbojet performance model
  test_data_reduction.py        # Synthetic test-bed data + calibration/reduction pipeline
  bracket_concept_sketch.py     # Dimensioned concept sketch for a load-cell mounting bracket
  build_portfolio_pdf.py        # Builds the combined PDF report
data/
  cycle_performance_table.csv   # Cycle model sweep results (rc = 3-20, 4 TIT values)
  raw_test_log.csv              # Simulated raw sensor log (pre-calibration)
  reduced_test_log.csv          # Post-calibration, corrected, QA-flagged data
figures/
  cycle_sweep.png
  test_data_reduction.png
  bracket_concept_sketch.png
Divyanshu_Samal_JetX_Portfolio.pdf   # Combined write-up (all three projects)
```

## Project 1 — Turbojet Performance Model

A station-by-station (intake → compressor → combustor → turbine → nozzle)
real-cycle model for a static single-spool turbojet, following standard
gas-turbine cycle relations (isentropic component efficiencies, an
exactly-solved combustor fuel-air-ratio energy balance, a turbine work
balance against the compressor, and a choked/unchoked propelling nozzle).

Run it:
```bash
python3 code/turbojet_cycle_model.py
```
Produces `figures/cycle_sweep.png` and `data/cycle_performance_table.csv`.

**Validation approach:** checked against the qualitative trends every
gas-turbine text predicts (specific thrust peaks with pressure ratio at
fixed TIT; TSFC shows a minimum) rather than a claimed match to a specific
textbook table I can't independently re-verify against the source.

## Project 2 — Test-Bed Data Reduction

Simulates a 120-second spool-up/steady/spool-down test run, generates
realistic raw sensor signals (load cell, thermocouple, pressure
transducer, speed pickup, fuel flowmeter) with noise, then reduces them
back to engineering units via explicit calibration constants, applies the
standard ISA-referenced speed correction, and flags basic QA issues.

Run it:
```bash
python3 code/test_data_reduction.py
```
Produces `figures/test_data_reduction.png`, `data/raw_test_log.csv`,
`data/reduced_test_log.csv`.

**Honesty note:** the raw data is simulated — there is no physical rig
behind it. The calibration/reduction/QA pipeline is real and is the
actual skill being demonstrated.

## Project 3 — Test-Stand Fixture Concept Sketch

A dimensioned 2D concept sketch (not parametric CAD) for a load-cell
mounting bracket, defining geometry and intent ahead of modelling it
properly in Siemens NX or CATIA.

```bash
python3 code/bracket_concept_sketch.py
```

**Next step (not yet done):** model this as a real parametric part in
Siemens NX or CATIA V5 (free student licenses available), with a proper
GD&T-annotated manufacturing drawing.

## Building the combined PDF report

```bash
python3 code/build_portfolio_pdf.py
```

## Dependencies

```bash
pip install numpy pandas matplotlib reportlab
```

## Honest scope

This was built in roughly a week alongside a full-time final-year
academic load. It is a foundation demonstrating engineering thinking,
not a claim of prior propulsion/testing experience. The cycle model uses
simplifying assumptions (constant cp, no bleed, no variable geometry) that
a production tool would not; the test data is synthetic; the CAD step is
a sketch, not a finished model. All of this is stated here rather than
implied otherwise.
