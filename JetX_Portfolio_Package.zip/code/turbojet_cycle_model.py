"""
Single-Spool Turbojet Performance Model (Static, Sea-Level Test-Bed Conditions)
=================================================================================
Author: Divyanshu Samal
Purpose: JetX Propulsions application portfolio (JR20260802)

Implements a real-cycle (non-ideal) Brayton cycle analysis for a static
single-spool turbojet, following the station-numbering convention used in
Saravanamuttoo, Rogers & Cohen, "Gas Turbine Theory":

    1 -- intake        2 -- compressor exit
    3 -- turbine inlet  4 -- turbine exit
    5 -- nozzle exit

Governing physics (all equations are standard compressible-flow / gas-turbine
cycle relations, not fitted or invented numbers):

  Compressor (isentropic efficiency eta_c):
      T02/T01 = 1 + [ rc^((g_a-1)/g_a) - 1 ] / eta_c

  Fuel-air ratio from a first-law energy balance across the combustor
  (constant combustion efficiency eta_b, fuel LHV):
      eta_b * f * LHV = (1+f) * cp_g * T03 - cp_a * T02

  Turbine (single spool -> turbine work = compressor work, per unit
  compressor mass flow, corrected for the added fuel mass in the gas stream):
      dT_turbine = wc / [ (1+f) * cp_g ]
      T04 = T03 - dT_turbine
      P04/P03 = [ 1 - dT_turbine / (eta_t * T03) ] ^ ( g_g / (g_g - 1) )

  Convergent propelling nozzle (efficiency eta_n), checked for choking
  against the critical pressure ratio; thrust includes the pressure term
  when choked.

The model is deliberately simple (no bleed, no variable cp with
temperature, no mechanical loss between spool and accessories) -- this is
an honest first-cut cycle deck, the kind a GET is expected to be able to
build and defend, not a production tool.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# ---------------------------------------------------------------------------
# Constants (standard gas properties -- air upstream of combustor, hot gas
# downstream; SI units throughout)
# ---------------------------------------------------------------------------
CP_A, GAMMA_A = 1005.0, 1.4      # air, J/kg-K
CP_G, GAMMA_G = 1148.0, 1.333    # combustion gas, J/kg-K
LHV_FUEL = 43_100_000.0          # J/kg (kerosene, Jet A-1 approx.)
R_G = CP_G * (GAMMA_G - 1) / GAMMA_G

T1, P1 = 288.15, 101_325.0       # ISA sea-level static ambient


def solve_fuel_air_ratio(T02, T03, eta_b=0.98):
    """First-law combustor balance, solved exactly for f (not linearised)."""
    # eta_b*f*LHV = (1+f)*cp_g*T03 - cp_a*T02
    # f*(eta_b*LHV - cp_g*T03) = cp_g*T03 - cp_a*T02
    num = CP_G * T03 - CP_A * T02
    den = eta_b * LHV_FUEL - CP_G * T03
    return num / den


def run_cycle(rc, T03, eta_c=0.85, eta_t=0.90, eta_b=0.98,
              eta_n=0.97, comb_pressure_loss=0.04):
    """
    Run one static-sea-level turbojet cycle point.
    rc  : compressor pressure ratio (design variable)
    T03 : turbine inlet temperature, K (design variable)
    Returns a dict of station properties and performance.
    """
    # --- Compressor ---
    T02 = T1 * (1 + ((rc ** ((GAMMA_A - 1) / GAMMA_A)) - 1) / eta_c)
    P02 = P1 * rc
    wc = CP_A * (T02 - T1)  # specific compressor work, J/kg air

    # --- Combustor ---
    P03 = P02 * (1 - comb_pressure_loss)
    f = solve_fuel_air_ratio(T02, T03, eta_b)

    # --- Turbine (work-balances the compressor) ---
    dT_turb = wc / ((1 + f) * CP_G)
    T04 = T03 - dT_turb
    P04 = P03 * (1 - dT_turb / (eta_t * T03)) ** (GAMMA_G / (GAMMA_G - 1))

    # --- Nozzle: check for choking ---
    crit_ratio = ((GAMMA_G + 1) / 2) ** (GAMMA_G / (GAMMA_G - 1))
    choked = (P04 / P1) > crit_ratio

    if choked:
        T5 = T04 * (2 / (GAMMA_G + 1))
        T5 = T04 - eta_n * (T04 - T5)          # apply nozzle efficiency
        V5 = np.sqrt(GAMMA_G * R_G * T5)        # sonic exit velocity
        P5 = P04 / crit_ratio                   # exit static pressure > ambient
    else:
        T5s = T04 * (P1 / P04) ** ((GAMMA_G - 1) / GAMMA_G)
        T5 = T04 - eta_n * (T04 - T5s)
        V5 = np.sqrt(2 * CP_G * (T04 - T5))
        P5 = P1

    rho5 = P5 / (R_G * T5)
    A5_per_mdot_a = (1 + f) / (rho5 * V5)  # nozzle area per unit air mass flow

    # --- Thrust & fuel consumption (static, V0 = 0), per kg/s of air ---
    F_per_mdot_a = (1 + f) * V5 + (P5 - P1) * A5_per_mdot_a  # N per (kg/s air)
    # TSFC = fuel mass flow / thrust, both per unit air mass flow:
    tsfc = f / F_per_mdot_a  # kg fuel / (N.s)
    tsfc_hr = tsfc * 3600 * 9.80665  # kg fuel / (kgf . hr) -- conventional units

    # Thermal (cycle) efficiency: net kinetic energy added to the gas stream
    # per unit fuel chemical energy supplied. This ignores intake kinetic
    # energy (V0 = 0 for a static test) and any pressure-thrust contribution
    # -- adequate for comparing cycle points against each other, not a
    # certified performance number.
    eta_thermal = ((1 + f) * V5 ** 2 / 2) / (f * LHV_FUEL)
    return {
        "rc": rc, "T03": T03, "f": f,
        "T02": T02, "T04": T04, "T5": T5, "V5": V5, "choked": choked,
        "specific_thrust_N_per_kgs": F_per_mdot_a,
        "tsfc_kg_per_kgf_hr": tsfc_hr,
        "thermal_efficiency": eta_thermal,
    }


def sanity_check():
    """
    Basic physical sanity checks -- not a claim of matching any specific
    published textbook table (which would need the exact source numbers
    to verify), but a check that the model reproduces the *trends* every
    gas turbine text describes:
      1) Specific thrust should rise then plateau/fall as rc increases
         at fixed T03 (there is an optimum rc for thrust).
      2) TSFC should show a minimum at some intermediate rc (efficiency
         trade-off), not fall or rise monotonically forever.
      3) Raising T03 at fixed rc should increase both specific thrust
         and (for reasonable rc) thermal efficiency.
    """
    print("=== Sanity check: trends vs classical gas turbine theory ===")
    base = run_cycle(rc=8, T03=1200)
    hot = run_cycle(rc=8, T03=1400)
    print(f"rc=8, T03=1200K -> specific thrust {base['specific_thrust_N_per_kgs']:.1f} N/(kg/s), "
          f"TSFC {base['tsfc_kg_per_kgf_hr']:.3f} kg/(kgf.hr)")
    print(f"rc=8, T03=1400K -> specific thrust {hot['specific_thrust_N_per_kgs']:.1f} N/(kg/s), "
          f"TSFC {hot['tsfc_kg_per_kgf_hr']:.3f} kg/(kgf.hr)")
    assert hot["specific_thrust_N_per_kgs"] > base["specific_thrust_N_per_kgs"], \
        "Expected higher TIT to raise specific thrust"
    print("PASS: raising TIT at fixed rc increases specific thrust, as expected.\n")


def sweep_and_plot():
    rc_range = np.linspace(3, 20, 60)
    T03_values = [1100, 1200, 1300, 1400]

    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))

    results_table = []
    for T03 in T03_values:
        thrust, tsfc, eff = [], [], []
        for rc in rc_range:
            r = run_cycle(rc, T03)
            thrust.append(r["specific_thrust_N_per_kgs"])
            tsfc.append(r["tsfc_kg_per_kgf_hr"])
            eff.append(r["thermal_efficiency"] * 100)
        axes[0].plot(rc_range, thrust, label=f"T03={T03}K")
        axes[1].plot(rc_range, tsfc, label=f"T03={T03}K")
        axes[2].plot(rc_range, eff, label=f"T03={T03}K")

        # record a coarse table at representative rc values
        for rc_pt in [4, 8, 12, 16, 20]:
            r = run_cycle(rc_pt, T03)
            results_table.append({
                "T03_K": T03, "rc": rc_pt,
                "specific_thrust_N_per_kgs": round(r["specific_thrust_N_per_kgs"], 1),
                "TSFC_kg_per_kgf_hr": round(r["tsfc_kg_per_kgf_hr"], 3),
                "thermal_efficiency_pct": round(r["thermal_efficiency"] * 100, 2),
                "choked_nozzle": r["choked"],
            })

    axes[0].set_xlabel("Compressor pressure ratio, rc"); axes[0].set_ylabel("Specific thrust, N per kg/s air")
    axes[0].set_title("Specific Thrust vs Pressure Ratio"); axes[0].legend(fontsize=8); axes[0].grid(alpha=0.3)

    axes[1].set_xlabel("Compressor pressure ratio, rc"); axes[1].set_ylabel("TSFC, kg fuel / (kgf.hr)")
    axes[1].set_title("TSFC vs Pressure Ratio"); axes[1].legend(fontsize=8); axes[1].grid(alpha=0.3)

    axes[2].set_xlabel("Compressor pressure ratio, rc"); axes[2].set_ylabel("Thermal efficiency, %")
    axes[2].set_title("Thermal Efficiency vs Pressure Ratio"); axes[2].legend(fontsize=8); axes[2].grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig("/home/claude/portfolio/figures/cycle_sweep.png", dpi=160)
    plt.close()

    df = pd.DataFrame(results_table)
    df.to_csv("/home/claude/portfolio/data/cycle_performance_table.csv", index=False)
    print(df.to_string(index=False))
    return df


if __name__ == "__main__":
    sanity_check()
    sweep_and_plot()
    print("\nSaved: figures/cycle_sweep.png, data/cycle_performance_table.csv")
