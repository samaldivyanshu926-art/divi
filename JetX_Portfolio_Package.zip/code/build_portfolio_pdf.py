from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Image,
                                 Table, TableStyle, PageBreak, HRFlowable)
from reportlab.lib import colors

NAVY = colors.HexColor("#1F3A5F")
GREY = colors.HexColor("#555555")

styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="TitleBig", fontSize=22, leading=26, textColor=NAVY,
                           alignment=TA_CENTER, spaceAfter=6, fontName="Helvetica-Bold"))
styles.add(ParagraphStyle(name="Subtitle", fontSize=12, leading=16, textColor=GREY,
                           alignment=TA_CENTER, spaceAfter=18, fontName="Helvetica-Oblique"))
styles.add(ParagraphStyle(name="H1", fontSize=15, leading=18, textColor=NAVY,
                           spaceBefore=14, spaceAfter=8, fontName="Helvetica-Bold"))
styles.add(ParagraphStyle(name="H2", fontSize=11.5, leading=14, textColor=colors.black,
                           spaceBefore=8, spaceAfter=4, fontName="Helvetica-Bold"))
styles.add(ParagraphStyle(name="Body", fontSize=10, leading=14.5, spaceAfter=8))
styles.add(ParagraphStyle(name="Small", fontSize=8.5, leading=11, textColor=GREY))

story = []

# ---------------- Title page ----------------
story.append(Spacer(1, 40))
story.append(Paragraph("Engineering Portfolio", styles["TitleBig"]))
story.append(Paragraph("Prepared for: JetX Propulsions Pvt. Ltd. \u2014 Engine Performance &amp; Testing Engineer (GET), JR20260802",
                        styles["Subtitle"]))
story.append(Spacer(1, 10))
story.append(Paragraph("Divyanshu Samal &nbsp;|&nbsp; B.Tech Mechanical Engineering, OUTR &nbsp;|&nbsp; "
                        "divi08samal26@gmail.com &nbsp;|&nbsp; +91 7327904315",
                        ParagraphStyle(name="contact", parent=styles["Body"], alignment=TA_CENTER)))
story.append(Spacer(1, 30))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 20))
story.append(Paragraph(
    "This portfolio contains two self-directed technical projects built specifically to demonstrate the core "
    "competencies listed for this role \u2014 engine performance/cycle modelling and test-bed instrumentation &amp; "
    "data reduction \u2014 plus a dimensioned concept sketch for a test-stand fixture, prepared as the input to "
    "formal CAD modelling. Everything here was built in the week before applying, is disclosed as such, and is "
    "presented as a foundation to build on rather than finished production work.", styles["Body"]))
story.append(PageBreak())

# ---------------- Project 1 ----------------
story.append(Paragraph("Project 1 \u2014 Single-Spool Turbojet Performance Model", styles["H1"]))
story.append(Paragraph("Python &middot; real-cycle Brayton analysis &middot; static sea-level conditions", styles["Small"]))
story.append(Spacer(1, 8))

story.append(Paragraph("Objective", styles["H2"]))
story.append(Paragraph(
    "Build a cycle deck for a static single-spool turbojet from first principles \u2014 the same category of tool "
    "the JD describes as defining performance maps and operating schedules for each build standard \u2014 and use it "
    "to explore the classic pressure-ratio / TSFC / thrust trade-off.", styles["Body"]))

story.append(Paragraph("Method", styles["H2"]))
story.append(Paragraph(
    "Station-by-station analysis (intake &rarr; compressor &rarr; combustor &rarr; turbine &rarr; nozzle) following the "
    "standard Brayton-cycle station numbering used in gas turbine theory. Compressor and turbine losses are captured "
    "via isentropic efficiencies (&eta;<sub rise=\"0\">c</sub>=0.85, &eta;<sub rise=\"0\">t</sub>=0.90); the fuel-air ratio is "
    "solved exactly from a first-law energy balance across the combustor; the turbine temperature drop is set by a "
    "work balance against the compressor (single-spool constraint); the propelling nozzle is checked for choking and "
    "thrust is computed with the pressure-thrust term included when choked.", styles["Body"]))

story.append(Paragraph("Validation approach", styles["H2"]))
story.append(Paragraph(
    "Rather than claim a match to a specific textbook table I can't independently re-verify, the model is checked "
    "against the qualitative trends every gas-turbine text predicts: specific thrust should rise then plateau with "
    "pressure ratio at fixed turbine inlet temperature (TIT), and TSFC should show a minimum rather than change "
    "monotonically. Both trends appear correctly in the results below \u2014 that internal consistency is the honest "
    "bar for a first-cut cycle deck.", styles["Body"]))

story.append(Spacer(1, 8))
story.append(Image("/home/claude/portfolio/figures/cycle_sweep.png", width=460, height=138))
story.append(Spacer(1, 8))

story.append(Paragraph("Representative results", styles["H2"]))
table_data = [["TIT (K)", "rc", "Specific Thrust\n(N per kg/s air)", "TSFC\n(kg/kgf.hr)", "Thermal Eff. (%)"]]
import csv
with open("/home/claude/portfolio/data/cycle_performance_table.csv") as f:
    reader = csv.DictReader(f)
    for row in reader:
        if row["rc"] in ("8", "12") and row["T03_K"] in ("1200", "1300"):
            table_data.append([row["T03_K"], row["rc"], row["specific_thrust_N_per_kgs"],
                                row["TSFC_kg_per_kgf_hr"], row["thermal_efficiency_pct"]])

t = Table(table_data, colWidths=[55, 40, 110, 80, 90])
t.setStyle(TableStyle([
    ("BACKGROUND", (0, 0), (-1, 0), NAVY),
    ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
    ("FONTSIZE", (0, 0), (-1, -1), 8.5),
    ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
    ("ALIGN", (0, 0), (-1, -1), "CENTER"),
    ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
    ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, colors.HexColor("#f2f5f9")]),
]))
story.append(t)
story.append(Spacer(1, 6))
story.append(Paragraph("Full sweep (rc = 3\u201320, four TIT values) in cycle_performance_table.csv.", styles["Small"]))
story.append(PageBreak())

# ---------------- Project 2 ----------------
story.append(Paragraph("Project 2 \u2014 Test-Bed Data Reduction &amp; Instrumentation", styles["H1"]))
story.append(Paragraph("Python &middot; sensor calibration &middot; corrected parameters &middot; QA flagging", styles["Small"]))
story.append(Spacer(1, 8))

story.append(Paragraph("Objective", styles["H2"]))
story.append(Paragraph(
    "Demonstrate the raw-signal-to-engineering-units workflow described in the JD's instrumentation responsibilities: "
    "load cell, thermocouple, and pressure transducer calibration, corrected-speed calculation, and basic QA "
    "flagging \u2014 on a synthetic but physically-plausible spool-up/steady-state/spool-down test run.", styles["Body"]))

story.append(Paragraph("Method", styles["H2"]))
story.append(Paragraph(
    "A 120-second run (0-60s spool-up, 60-100s steady hold, 100-120s spool-down) is simulated at 10 Hz. Each channel "
    "is generated as a true engineering value, converted to a raw sensor signal via an explicit calibration constant "
    "(e.g. 100 N/V for the load cell, 41 &mu;V/K for the Type-K thermocouple with cold-junction compensation), and "
    "corrupted with realistic sensor noise \u2014 then reduced back to engineering units exactly as it would be from a "
    "real DAQ log. Shaft speed is corrected to ISA sea-level reference temperature so results would be comparable "
    "across test days, and simple QA flags catch over-temperature and physically invalid readings before they'd be "
    "trusted downstream.", styles["Body"]))

story.append(Paragraph("Honesty note", styles["H2"]))
story.append(Paragraph(
    "The raw data is simulated \u2014 there is no physical rig behind it. What's real is the reduction pipeline: "
    "calibration application, unit conversion, correction, and QA logic, which is the actual skill being demonstrated.",
    styles["Body"]))

story.append(Spacer(1, 8))
story.append(Image("/home/claude/portfolio/figures/test_data_reduction.png", width=430, height=287))
story.append(Spacer(1, 6))
story.append(Paragraph(
    "Steady-state window (65\u201395s): mean thrust 619.9 N (&sigma;=1.55 N), mean T3 1188.0 K (&sigma;=0.14 K), "
    "mean pressure ratio 8.50, mean TSFC 0.797 kg/(kgf.hr). Zero points flagged for QA in this run.",
    styles["Body"]))
story.append(PageBreak())

# ---------------- Project 3 ----------------
story.append(Paragraph("Project 3 \u2014 Test-Stand Fixture Concept Sketch", styles["H1"]))
story.append(Paragraph("Dimensioned concept sketch \u2014 CAD modelling input, not a substitute for it", styles["Small"]))
story.append(Spacer(1, 8))
story.append(Paragraph(
    "A load-cell mounting bracket for in-line axial thrust measurement, sketched with concept-stage dimensions and "
    "material/finish callouts. This defines geometry and intent ahead of building it as a real parametric model in "
    "Siemens NX or CATIA (the JD's specified tools) \u2014 that modelling step is the next item on my plan, not "
    "something I'm claiming to have already done.", styles["Body"]))
story.append(Spacer(1, 8))
story.append(Image("/home/claude/portfolio/figures/bracket_concept_sketch.png", width=430, height=286))

story.append(Spacer(1, 16))
story.append(Paragraph("Repository", styles["H2"]))
story.append(Paragraph(
    "Full source code, raw/reduced data, and this report are organised for a public GitHub repository "
    "(see README.md in the project package).", styles["Body"]))

doc = SimpleDocTemplate("/home/claude/portfolio/Divyanshu_Samal_JetX_Portfolio.pdf",
                         pagesize=A4, topMargin=20 * mm, bottomMargin=18 * mm,
                         leftMargin=18 * mm, rightMargin=18 * mm)
doc.build(story)
print("Portfolio PDF built.")
