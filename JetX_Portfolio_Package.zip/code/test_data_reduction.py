"""
Test-Bed Data Reduction & Instrumentation Script
=================================================
Author: Divyanshu Samal
Purpose: JetX Propulsions application portfolio (JR20260802)

What this demonstrates (mirrors the JD's "Instrumentation & DAQ" and
"Test execution & data" responsibilities):
  1. A synthetic but physically-plausible test-bed run: a spool-up
     transient (0 -> 90,000 RPM) followed by a steady-state hold,
     with realistic sensor noise added to each channel.
  2. RAW SENSOR SIGNAL -> ENGINEERING UNITS conversion using explicit
     calibration constants (the load-cell/thermocouple/pressure-
     transducer calibration step described in the JD).
  3. DATA REDUCTION: computing corrected parameters (speed corrected
     for inlet temperature, per standard gas-turbine test practice)
     so that results are comparable across ambient conditions.
  4. Basic QA: flagging any out-of-range or physically implausible
     points before they'd be trusted.

IMPORTANT: The raw data here is SIMULATED for demonstration -- there is
no physical test rig behind it. Every step, however (calibration,
correction, QA), is written the way it would be for real logged data,
and is the honest scope of what can be shown without access to a test
cell.
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

rng = np.random.default_rng(42)

# ---------------------------------------------------------------------------
# 1. SYNTHETIC RAW TEST RUN
#    120 seconds: 0-60s spool-up (idle -> 90,000 RPM), 60-100s steady hold,
#    100-120s spool-down. Sampled at 10 Hz (typical for slow thermodynamic
#    channels; a real DAQ would log vibration/pressure much faster).
# ---------------------------------------------------------------------------
t = np.arange(0, 120, 0.1)
N_max = 90_000  # rpm

rpm_true = np.piecewise(
    t,
    [t < 60, (t >= 60) & (t < 100), t >= 100],
    [lambda t: N_max * (t / 60) ** 1.3,
     lambda t: N_max,
     lambda t: N_max * np.clip(1 - (t - 100) / 20, 0, 1)]
)

# Derived "true" quantities from a simplified engine map (not the cycle
# model above -- a lower-order empirical map is normal for quick-look
# test-bed reduction while the full cycle deck runs separately)
pr_true = 1 + 7.5 * (rpm_true / N_max) ** 2          # compressor pressure ratio
T3_true = 288 + 900 * (rpm_true / N_max) ** 1.5      # turbine inlet temp, K (approx)
thrust_true = 620 * (rpm_true / N_max) ** 2.2         # N, static thrust
fuel_flow_true = 0.014 * (rpm_true / N_max) ** 1.8    # kg/s

# ---------------------------------------------------------------------------
# 2. RAW SENSOR SIGNALS (engineering quantity -> raw counts/voltage,
#    then corrupted with realistic noise, exactly as a real DAQ would see)
# ---------------------------------------------------------------------------
# Load cell: 0-1000 N range -> 0-10 V, calibration slope/offset applied
LOADCELL_SLOPE = 100.0   # N per V
LOADCELL_OFFSET = -2.0   # N (small zero-offset error, must be calibrated out)
loadcell_raw_V = (thrust_true - LOADCELL_OFFSET) / LOADCELL_SLOPE
loadcell_raw_V += rng.normal(0, 0.015, size=t.shape)  # sensor + electrical noise

# Type-K thermocouple (simplified linear approx near this range): ~41 uV/K
TC_SENS_V_PER_K = 41e-6
TC_COLD_JUNCTION_K = 298.0  # cold-junction compensation reference
tc_raw_V = (T3_true - TC_COLD_JUNCTION_K) * TC_SENS_V_PER_K
tc_raw_V += rng.normal(0, 6e-6, size=t.shape)

# Pressure transducer: 0-10 bar -> 0.5-4.5 V (typical ratiometric sensor)
PT_SPAN_BAR = 10.0
pt_raw_V = 0.5 + (pr_true / PT_SPAN_BAR) * 4.0
pt_raw_V += rng.normal(0, 0.01, size=t.shape)

# Magnetic speed pickup: pulses/rev -> frequency -> rpm (assume clean-ish,
# small quantization noise from tooth-count resolution)
rpm_meas = rpm_true + rng.normal(0, 40, size=t.shape)

# Fuel flow meter (turbine flowmeter, pulses -> kg/s, small noise)
fuel_flow_meas = fuel_flow_true + rng.normal(0, 0.0003, size=t.shape)

raw_df = pd.DataFrame({
    "time_s": t,
    "loadcell_V": loadcell_raw_V,
    "thermocouple_V": tc_raw_V,
    "pressure_transducer_V": pt_raw_V,
    "speed_pickup_rpm": rpm_meas,
    "fuel_flowmeter_kg_s": fuel_flow_meas,
})
raw_df.to_csv("/home/claude/portfolio/data/raw_test_log.csv", index=False)


# ---------------------------------------------------------------------------
# 3. DATA REDUCTION -- raw signal -> engineering units via calibration
# ---------------------------------------------------------------------------
def reduce_test_data(raw: pd.DataFrame, T_ambient_K: float = 288.15,
                      P_ambient_bar: float = 1.01325) -> pd.DataFrame:
    df = raw.copy()

    # Load cell -> thrust (undo the known calibration slope/offset)
    df["thrust_N"] = df["loadcell_V"] * LOADCELL_SLOPE + LOADCELL_OFFSET
    df["thrust_N"] = df["thrust_N"].clip(lower=0)  # thrust can't be negative

    # Thermocouple -> temperature (cold-junction compensated)
    df["T3_K"] = df["thermocouple_V"] / TC_SENS_V_PER_K + TC_COLD_JUNCTION_K

    # Pressure transducer -> pressure ratio
    df["pressure_ratio"] = ((df["pressure_transducer_V"] - 0.5) / 4.0) * PT_SPAN_BAR

    # Speed -> corrected speed (standard gas-turbine test correction,
    # referencing ISA sea-level static so runs on different days are
    # comparable):
    #     N_corrected = N_measured / sqrt(T_ambient / T_ISA)
    T_ISA = 288.15
    df["N_rpm"] = df["speed_pickup_rpm"].clip(lower=0)
    df["N_corrected_rpm"] = df["N_rpm"] / np.sqrt(T_ambient_K / T_ISA)

    # TSFC from measured thrust + fuel flow
    with np.errstate(divide="ignore", invalid="ignore"):
        df["TSFC_kg_per_kgf_hr"] = np.where(
            df["thrust_N"] > 20,
            df["fuel_flowmeter_kg_s"] * 3600 * 9.80665 / df["thrust_N"],
            np.nan
        )

    # --- Basic QA flags (the kind a test engineer checks before trusting
    # a data point) ---
    df["qa_flag"] = "OK"
    df.loc[df["T3_K"] > 1500, "qa_flag"] = "OVER_TEMP_CHECK"
    df.loc[df["pressure_ratio"] < 0.9, "qa_flag"] = "SENSOR_SUSPECT_LOW_PR"
    df.loc[df["thrust_N"] < 0, "qa_flag"] = "NEGATIVE_THRUST_INVALID"

    return df


reduced_df = reduce_test_data(raw_df)
reduced_df.to_csv("/home/claude/portfolio/data/reduced_test_log.csv", index=False)

flagged = reduced_df[reduced_df["qa_flag"] != "OK"]
print(f"Data reduction complete: {len(reduced_df)} samples, {len(flagged)} flagged for QA review.")

steady = reduced_df[(reduced_df["time_s"] >= 65) & (reduced_df["time_s"] <= 95)]
print("\n--- Steady-state summary (65-95 s window) ---")
print(f"Mean thrust        : {steady['thrust_N'].mean():.1f} N  (std {steady['thrust_N'].std():.2f} N)")
print(f"Mean T3            : {steady['T3_K'].mean():.1f} K  (std {steady['T3_K'].std():.2f} K)")
print(f"Mean pressure ratio: {steady['pressure_ratio'].mean():.2f}  (std {steady['pressure_ratio'].std():.3f})")
print(f"Mean N_corrected   : {steady['N_corrected_rpm'].mean():.0f} rpm")
print(f"Mean TSFC          : {steady['TSFC_kg_per_kgf_hr'].mean():.3f} kg/(kgf.hr)")

# ---------------------------------------------------------------------------
# 4. PLOTS
# ---------------------------------------------------------------------------
fig, axes = plt.subplots(2, 2, figsize=(12, 8))

axes[0, 0].plot(reduced_df["time_s"], reduced_df["N_rpm"], color="tab:blue", lw=1)
axes[0, 0].set_title("Shaft Speed vs Time"); axes[0, 0].set_xlabel("Time, s"); axes[0, 0].set_ylabel("RPM")
axes[0, 0].grid(alpha=0.3)

axes[0, 1].plot(reduced_df["time_s"], reduced_df["thrust_N"], color="tab:red", lw=1)
axes[0, 1].set_title("Thrust vs Time"); axes[0, 1].set_xlabel("Time, s"); axes[0, 1].set_ylabel("Thrust, N")
axes[0, 1].grid(alpha=0.3)

axes[1, 0].plot(reduced_df["time_s"], reduced_df["T3_K"], color="tab:orange", lw=1)
axes[1, 0].set_title("Turbine Inlet Temperature vs Time"); axes[1, 0].set_xlabel("Time, s"); axes[1, 0].set_ylabel("T3, K")
axes[1, 0].grid(alpha=0.3)

sc = axes[1, 1].scatter(reduced_df["N_corrected_rpm"], reduced_df["thrust_N"],
                         c=reduced_df["TSFC_kg_per_kgf_hr"], cmap="viridis", s=6)
axes[1, 1].set_title("Thrust vs Corrected Speed (colour = TSFC)")
axes[1, 1].set_xlabel("Corrected speed, rpm"); axes[1, 1].set_ylabel("Thrust, N")
cbar = plt.colorbar(sc, ax=axes[1, 1]); cbar.set_label("TSFC, kg/(kgf.hr)")
axes[1, 1].grid(alpha=0.3)

plt.tight_layout()
plt.savefig("/home/claude/portfolio/figures/test_data_reduction.png", dpi=160)
plt.close()

print("\nSaved: data/raw_test_log.csv, data/reduced_test_log.csv, figures/test_data_reduction.png")
