"""
Concept Sketch: Test-Stand Load-Cell Mounting Bracket
======================================================
This is a DIMENSIONED 2D CONCEPT SKETCH, not parametric CAD. It exists to
define the part before modelling it properly in Siemens NX / CATIA / a
free equivalent (see the README for the actual modelling steps). Presenting
this sketch as a finished CAD deliverable would be dishonest -- it is the
input to that step, not a replacement for it.

Design intent: a rigid L-bracket that mounts a thrust load cell in-line
with the engine centreline, isolating axial load onto the cell while
constraining other degrees of freedom via a slotted base -- the kind of
simple test-bed fixture described in the JD's "Test-bed & facility
engineering" responsibility.
"""

import matplotlib.pyplot as plt
import matplotlib.patches as patches

fig, ax = plt.subplots(figsize=(9, 6))

# Base plate
base = patches.Rectangle((0, 0), 160, 12, linewidth=1.5, edgecolor="black", facecolor="#e8eef5")
ax.add_patch(base)

# Vertical riser
riser = patches.Rectangle((10, 12), 12, 70, linewidth=1.5, edgecolor="black", facecolor="#e8eef5")
ax.add_patch(riser)

# Load cell mounting boss (circle) on riser
lc = patches.Circle((16, 60), 6, linewidth=1.5, edgecolor="black", facecolor="#f5d6a8")
ax.add_patch(lc)

# Slotted holes in base (for alignment adjustment)
for x0 in (25, 70, 115, 140):
    slot = patches.FancyBboxPatch((x0, 3), 14, 6, boxstyle="round,pad=0,rounding_size=3",
                                    linewidth=1.2, edgecolor="black", facecolor="white")
    ax.add_patch(slot)

# Centreline (engine thrust axis)
ax.plot([-10, 170], [60, 60], linestyle="--", color="gray", linewidth=1)
ax.text(172, 60, "Engine thrust\ncentreline", fontsize=8, color="gray", va="center")

# Dimension callouts
def dim_h(x1, x2, y, text):
    ax.annotate("", xy=(x1, y), xytext=(x2, y), arrowprops=dict(arrowstyle="<->", lw=0.8))
    ax.text((x1 + x2) / 2, y + 2, text, ha="center", fontsize=8)

def dim_v(y1, y2, x, text):
    ax.annotate("", xy=(x, y1), xytext=(x, y2), arrowprops=dict(arrowstyle="<->", lw=0.8))
    ax.text(x + 3, (y1 + y2) / 2, text, fontsize=8, va="center")

dim_h(0, 160, -8, "160 mm base length")
dim_v(0, 82, -14, "82 mm overall height")
dim_h(10, 22, 86, "12 mm riser thickness")
dim_h(25, 39, -2, "M8 slot x4 (adjustment)")

ax.text(16, 60, "\u2300 load\ncell boss\nM10x1.25", fontsize=7, ha="center", va="center")
ax.text(80, -20, "MATERIAL: Al 6061-T6   |   FINISH: as-machined   |   NOTE: all fillets 3 mm min\n"
                  "TOLERANCE (concept-stage, non-GD&T): \u00b10.2 mm linear",
        fontsize=8, ha="center")

ax.set_xlim(-25, 190)
ax.set_ylim(-30, 100)
ax.set_aspect("equal")
ax.axis("off")
ax.set_title("Test-Stand Load-Cell Mounting Bracket \u2014 Concept Sketch (front view)\n"
              "For CAD modelling reference only \u2014 not a manufacturing drawing", fontsize=11)

plt.tight_layout()
plt.savefig("/home/claude/portfolio/figures/bracket_concept_sketch.png", dpi=160)
plt.close()
print("Saved: figures/bracket_concept_sketch.png")
